#!/usr/bin/env bash
# One-shot Azure deploy: RG + ACR + Postgres + Container Apps
set -euo pipefail

RG="${RG:-rg-orahdex-prod}"
LOCATION="${LOCATION:-eastus}"
ACR="${ACR:-orahdexacr$RANDOM}"
ACR="${ACR//[^a-z0-9]/}"
ENV_NAME="${ENV_NAME:-orahdex-env}"
APP_NAME="${APP_NAME:-orahdex-api}"
PG_NAME="${PG_NAME:-orahdex-pg-$RANDOM}"
PG_NAME="${PG_NAME//[^a-z0-9-]/}"
PG_ADMIN="${PG_ADMIN:-orahadmin}"
PG_PASSWORD="${PG_PASSWORD:-$(openssl rand -base64 24)}"

echo "==> RG=$RG LOCATION=$LOCATION ACR=$ACR APP=$APP_NAME PG=$PG_NAME"

az group create -n "$RG" -l "$LOCATION" --output none

echo "==> Azure Container Registry"
az acr create -g "$RG" -n "$ACR" --sku Basic --output none
az acr login -n "$ACR"

echo "==> PostgreSQL Flexible Server (public access for bootstrap — lock down later)"
az postgres flexible-server create \
  -g "$RG" -n "$PG_NAME" -l "$LOCATION" \
  --admin-user "$PG_ADMIN" --admin-password "$PG_PASSWORD" \
  --sku-name Standard_B1ms --tier Burstable \
  --storage-size 32 --version 16 \
  --yes --output none

az postgres flexible-server db create -g "$RG" -s "$PG_NAME" -d orahdex --output none
az postgres flexible-server firewall-rule create \
  -g "$RG" -n "$PG_NAME" -r AllowAzureServices \
  --start-ip-address 0.0.0.0 --end-ip-address 0.0.0.0 --output none

DATABASE_URL="postgresql://${PG_ADMIN}:${PG_PASSWORD}@${PG_NAME}.postgres.database.azure.com:5432/orahdex?sslmode=require"
echo "DATABASE_URL saved to ./azure-db.url (protect this file)"
echo "$DATABASE_URL" > azure-db.url
chmod 600 azure-db.url

echo "==> Build image (run from monorepo root)"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
[[ -f "$REPO_ROOT/package.json" ]] || REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$REPO_ROOT"
DOCKERFILE="deploy/Dockerfile"
[[ -f "$DOCKERFILE" ]] || DOCKERFILE="Dockerfile"

IMAGE="${ACR}.azurecr.io/orahdex-api:latest"
az acr build -r "$ACR" -t orahdex-api:latest -f "$DOCKERFILE" .

echo "==> Container Apps environment + app"
az extension add --name containerapp --upgrade -y 2>/dev/null || true
az provider register --namespace Microsoft.App --wait 2>/dev/null || true
az provider register --namespace Microsoft.OperationalInsights --wait 2>/dev/null || true

az containerapp env create -g "$RG" -n "$ENV_NAME" -l "$LOCATION" --output none

az containerapp create \
  -g "$RG" -n "$APP_NAME" \
  --environment "$ENV_NAME" \
  --image "$IMAGE" \
  --registry-server "${ACR}.azurecr.io" \
  --target-port 8080 \
  --ingress external \
  --cpu 1.0 --memory 2.0Gi \
  --min-replicas 1 --max-replicas 2 \
  --env-vars \
    "NODE_ENV=production" \
    "PORT=8080" \
    "DATABASE_URL=secretref:database-url" \
  --secrets "database-url=$DATABASE_URL" \
  --output none

FQDN=$(az containerapp show -g "$RG" -n "$APP_NAME" --query properties.configuration.ingress.fqdn -o tsv)
echo "==> API URL: https://$FQDN"
echo "==> Add remaining secrets via:"
echo "    az containerapp secret set -g $RG -n $APP_NAME --secrets evm-wallet-secret=... stripe-secret-key=..."
echo "==> Then bind: az containerapp update ... --set-env-vars EVM_WALLET_SECRET=secretref:evm-wallet-secret"
echo "==> PG password was auto-generated — see azure-db.url"
