# OrahDEX — fix-all checklist

Addresses audit findings for **aaurah.org / OrahDEX** + production deploy.

## Status legend

- [x] Fixed in this deploy kit
- [ ] You must do in Cloudflare / DNS / secrets / GitHub

---

## A. Domain & DNS

| Issue | Fix | Who |
|-------|-----|-----|
| Live site is `aaurah.org`, docs say `orahdex.org` | Pick one canonical domain; 301 the other | [ ] You — Cloudflare Redirect |
| `orahdex.org` offline / Replit placeholder | Point DNS to same origin as aaurah.org or redirect | [ ] You |
| `orahdex.app` Vercel 404 | Remove dead DNS or finish deploy | [ ] You |
| Canonical / OG tags point at orahdex.org | Rebuild frontend with `PUBLIC_URL=https://aaurah.org` (or chosen domain) | [ ] You — env at build |

**Recommended canonical:** `https://aaurah.org` (already live + Cloudflare).

---

## B. Cloudflare Tunnel

| Issue | Fix | Who |
|-------|-----|-----|
| Tunnel config targeted `orahdex.app` | Use `cloudflare/tunnel-config.yml` (aaurah.org + api.aaurah.org) | [x] Kit |
| Credentials under Termux path | Run `cloudflared` on VPS/systemd; path `/etc/cloudflared/` | [ ] You |
| Tunnel not aligned with live traffic | Either use tunnel as origin **or** pure CF proxy to cloud host — not both inconsistently | [ ] You |

---

## C. Security

| Issue | Fix | Who |
|-------|-----|-----|
| Missing CSP / frame / referrer headers | Apply `cloudflare/security-headers.md` | [x] Kit guide / [ ] You apply |
| Detailed `/api/health` public | Rate-limit + restrict detail; use `/api/healthz` for probes | [ ] You |
| Relayer / wallet secrets | Key Vault / Secret Manager only; rotate if ever on Termux/Replit | [ ] You |
| WAF / rate limits | Rules in security-headers.md | [ ] You |

---

## D. Deploy architecture

| Issue | Fix | Who |
|-------|-----|-----|
| No production Docker | `Dockerfile` + `docker-compose.yml` | [x] Kit |
| Azure one-shot | `azure/deploy.sh` + bicep | [x] Kit |
| GCP one-shot | `gcp/deploy.sh` + cloudbuild | [x] Kit |
| In-process workers duplicate on scale | **min/max replicas = 1** until leader election | [x] Documented |
| DB schema | `scripts/migrate-db.sh` | [x] Kit |
| GitHub Actions | `.github/workflows/deploy-gcp.yml` | [x] Kit |

---

## E. GitHub connector (this chat)

| Issue | Fix |
|-------|-----|
| 403 on push | App has Contents **read only** — set **Contents: Read and write** on GitHub App, or commit zip manually |

Manual commit:

```bash
cd OrahDEX
# copy this folder to ./deploy
git add deploy
git commit -m "Add production deploy kit + Cloudflare fixes"
git push
```

---

## F. Go-live order (do in sequence)

1. Fill `deploy/.env` from `.env.example` (real secrets, local only).
2. `docker compose up -d --build` **or** `./gcp/deploy.sh` / `./azure/deploy.sh`.
3. Run `scripts/migrate-db.sh` against `DATABASE_URL`.
4. Confirm `GET /api/health` → ok.
5. Cloudflare: Full strict SSL, redirects, security headers, rate limits.
6. Point `aaurah.org` / `api.aaurah.org` at origin (tunnel or cloud LB).
7. Register Stripe + EVM webhooks to `https://api.aaurah.org/...`.
8. Rebuild frontend with correct canonical URL; purge CF cache.
9. Keep **one** API instance.

---

## G. Do not

- Scale API to N replicas without splitting workers.
- Commit `.env` or relayer keys.
- Use Termux as production tunnel host.
- Leave both aaurah.org and orahdex.org as competing live origins without redirects.
