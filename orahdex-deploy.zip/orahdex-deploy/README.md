# OrahDEX production deploy kit (fixed)

Docker + Azure + GCP + Cloudflare fixes for aaurah/OrahDEX.

**Read first:** [FIXES.md](./FIXES.md)

## Quick start

```bash
cp deploy/.env.example deploy/.env
# edit secrets — never commit .env

cd deploy
docker compose up -d --build

DATABASE_URL='postgresql://orahdex:PASSWORD@localhost:5432/orahdex' \
  ./scripts/migrate-db.sh ..
```

- API: http://localhost:8080
- Frontend: http://localhost:8081

## Cloud

```bash
export PROJECT_ID=your-project && ./gcp/deploy.sh
az login && ./azure/deploy.sh
```

## Cloudflare

1. Apply `cloudflare/security-headers.md`
2. Use `cloudflare/tunnel-config.yml` on a stable host (not Termux)
3. Canonical: **aaurah.org** — 301 orahdex.org → aaurah.org

## Hard rules

1. API replicas = 1
2. Cloud Run: --no-cpu-throttling --min-instances=1
3. NODE_OPTIONS=--max-old-space-size=4096
4. Secrets only in env / secret manager
5. Migrate DB before traffic
