# Cloudflare edge fixes for aaurah.org / OrahDEX

Apply in **Cloudflare Dashboard → Rules → Transform Rules → Modify Response Header**
(or Configuration Rules / Workers).

## 1. Security response headers (all requests)

| Header | Value |
|--------|--------|
| `Strict-Transport-Security` | `max-age=31536000; includeSubDomains; preload` |
| `X-Content-Type-Options` | `nosniff` |
| `X-Frame-Options` | `SAMEORIGIN` |
| `Referrer-Policy` | `strict-origin-when-cross-origin` |
| `Permissions-Policy` | `camera=(), microphone=(), geolocation=()` |
| `Cross-Origin-Opener-Policy` | `same-origin` |

Optional CSP (tune if wallets/scripts break):

```
default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://cdn.jsdelivr.net https://*.walletconnect.com; connect-src 'self' https: wss:; img-src 'self' data: https:; style-src 'self' 'unsafe-inline'; frame-ancestors 'self'
```

## 2. Rate limiting (Security → WAF → Rate limiting rules)

| Path | Limit | Action |
|------|-------|--------|
| `/api/*` | 120 req / 1 min / IP | Block / Challenge |
| `/api/health*` | 30 req / 1 min / IP | Block |
| `/api/order/*` | 60 req / 1 min / IP | Managed Challenge |
| `/api/webhooks/*` | allow known provider IPs | Skip rate limit if possible |

## 3. Domain canonicalization

**Bulk Redirect** or **Dynamic Redirect**:

- `orahdex.org/*` → `https://aaurah.org/$1` (301) **or** reverse if you pick orahdex.org as canonical
- `www.aaurah.org/*` → `https://aaurah.org/$1` (301)

Pick **one** canonical host and update HTML `<link rel="canonical">` + Open Graph URLs in the frontend build.

## 4. SSL / TLS

- Mode: **Full (strict)**
- Minimum TLS: **1.2**
- Always Use HTTPS: **On**
- Automatic HTTPS Rewrites: **On**

## 5. Health endpoint

Prefer public minimal health:

- Cloudflare Worker or origin: `/api/healthz` → `{ "status": "ok" }` only  
- Keep detailed `/api/health` behind admin auth or Cloudflare Access

## 6. Bot / WAF

- Enable **Bot Fight Mode** or Super Bot Fight (paid)
- Managed ruleset: Cloudflare Managed + OWASP (if plan allows)
- Challenge suspicious ASNs on `/api/admin/*`
