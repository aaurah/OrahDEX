#!/usr/bin/env bash
# Apply OrahDEX Drizzle SQL to DATABASE_URL
set -euo pipefail

: "${DATABASE_URL:?Set DATABASE_URL}"

REPO_ROOT="${1:-.}"
SQL="$REPO_ROOT/lib/db/drizzle/0000_noisy_wilson_fisk.sql"

if [[ ! -f "$SQL" ]]; then
  echo "Migration file not found: $SQL"
  echo "Usage: DATABASE_URL=... $0 /path/to/OrahDEX"
  exit 1
fi

if ! command -v psql >/dev/null; then
  echo "psql required (apt install postgresql-client)"
  exit 1
fi

echo "Applying $SQL ..."
sed 's/--> statement-breakpoint/;/g' "$SQL" | psql "$DATABASE_URL"
echo "Done. Also create internal_bsv_wallets if required by lib/internalBsvWallet.ts"
