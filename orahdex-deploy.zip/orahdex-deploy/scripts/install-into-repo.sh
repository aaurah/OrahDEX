#!/usr/bin/env bash
# Copy this deploy kit into an OrahDEX clone as ./deploy
set -euo pipefail

REPO_ROOT="${1:-}"
if [[ -z "$REPO_ROOT" || ! -f "$REPO_ROOT/package.json" ]]; then
  echo "Usage: $0 /path/to/OrahDEX"
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
KIT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

mkdir -p "$REPO_ROOT/deploy"
rsync -a --exclude '.git' "$KIT_ROOT/" "$REPO_ROOT/deploy/"

# Workflow at repo root
mkdir -p "$REPO_ROOT/.github/workflows"
if [[ -f "$REPO_ROOT/deploy/.github/workflows/deploy-gcp.yml" ]]; then
  cp "$REPO_ROOT/deploy/.github/workflows/deploy-gcp.yml" \
     "$REPO_ROOT/.github/workflows/deploy-gcp.yml"
fi

chmod +x "$REPO_ROOT/deploy/gcp/deploy.sh" \
         "$REPO_ROOT/deploy/azure/deploy.sh" \
         "$REPO_ROOT/deploy/scripts/migrate-db.sh" \
         "$REPO_ROOT/deploy/scripts/install-into-repo.sh" 2>/dev/null || true

echo "Installed deploy kit into $REPO_ROOT/deploy"
echo "Next:"
echo "  cd $REPO_ROOT"
echo "  cp deploy/.env.example deploy/.env"
echo "  # edit secrets"
echo "  git add deploy .github/workflows/deploy-gcp.yml"
echo "  git commit -m 'Add production deploy kit'"
echo "  git push"
