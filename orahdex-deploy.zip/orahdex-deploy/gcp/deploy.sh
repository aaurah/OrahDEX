#!/usr/bin/env bash
# One-shot GCP deploy for OrahDEX API
# Prerequisites: gcloud auth, billing, APIs enabled
set -euo pipefail

PROJECT_ID="${PROJECT_ID:?Set PROJECT_ID}"
REGION="${REGION:-us-central1}"
SERVICE="${SERVICE:-orahdex-api}"
REPO="${REPO:-orahdex}"
SQL_INSTANCE="${SQL_INSTANCE:-${PROJECT_ID}:${REGION}:orahdex-pg}"
IMAGE="${REGION}-docker.pkg.dev/${PROJECT_ID}/${REPO}/api:latest"

echo "==> Project: $PROJECT_ID  Region: $REGION"

gcloud config set project "$PROJECT_ID"

echo "==> Enable APIs"
gcloud services enable \
  run.googleapis.com \
  sqladmin.googleapis.com \
  secretmanager.googleapis.com \
  artifactregistry.googleapis.com \
  cloudbuild.googleapis.com \
  --quiet

echo "==> Artifact Registry"
gcloud artifacts repositories describe "$REPO" --location="$REGION" 2>/dev/null \
  || gcloud artifacts repositories create "$REPO" \
       --repository-format=docker \
       --location="$REGION" \
       --description="OrahDEX images"

echo "==> Build & push (from repo root)"
# Run from monorepo root with deploy/ as sibling folder, or adjust -f path
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
# If package is standalone "orahdex-deploy", expect OrahDEX clone at ../OrahDEX
if [[ ! -f "$REPO_ROOT/package.json" ]]; then
  REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
fi

cd "$REPO_ROOT"
# Prefer Dockerfile inside deploy folder copied into repo as deploy/
DOCKERFILE="deploy/Dockerfile"
[[ -f "$DOCKERFILE" ]] || DOCKERFILE="Dockerfile"

gcloud builds submit --tag "$IMAGE" -f "$DOCKERFILE" .

echo "==> Deploy Cloud Run (min instances=1, no CPU throttle)"
gcloud run deploy "$SERVICE" \
  --image="$IMAGE" \
  --region="$REGION" \
  --platform=managed \
  --port=8080 \
  --memory=2Gi \
  --cpu=1 \
  --min-instances=1 \
  --max-instances=2 \
  --no-cpu-throttling \
  --timeout=300 \
  --set-env-vars="NODE_ENV=production,PORT=8080" \
  --add-cloudsql-instances="$SQL_INSTANCE" \
  --allow-unauthenticated

echo "==> Done. Map secrets in Cloud Run → Edit → Variables & secrets"
echo "    Required: DATABASE_URL, EVM_WALLET_SECRET, STRIPE_*, LETSEXCHANGE_API_KEY, ..."
gcloud run services describe "$SERVICE" --region="$REGION" --format='value(status.url)'
